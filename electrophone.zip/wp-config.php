<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'id5041773_wp_36eca184f7e343896d593d6020386f04' );

/** MySQL database username */
define( 'DB_USER', 'id5041773_wp_36eca184f7e343896d593d6020386f04' );

/** MySQL database password */
define( 'DB_PASSWORD', '8e5cf367a9130d5ed334eabceb6aa32d7e922569' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '$1&#~.^z[?BJv]a?)W;%6BX<JCs055c]VT#JKi;x;ylM+]9ukq!lbM.)BCIEg)L/' );
define( 'SECURE_AUTH_KEY',  'C)atUG(Ku`hpn{[iQ5[mzLVC0!UuAGflWKo`s)iCpPFnv0jBwdjd>S4W;9_Nj9F%' );
define( 'LOGGED_IN_KEY',    'dvMTE5/$~1PNp{!X?(6+w>9,<2`S4R[kNDVA.R(WBX&?u&,QiF%Dxli]s|JO;po.' );
define( 'NONCE_KEY',        '#5TwD0Pck*]WWW&H4evDLi5eha)wxt:1|aF%d%iIkV#]9Q`{^_zagtcG E3WwVdO' );
define( 'AUTH_SALT',        'AVDVNbqhvuM^Ds<2}9KpD<A?a<J(yH nIu.3|Rc-k)+L&`i[0J/z67(s(`RX+qU^' );
define( 'SECURE_AUTH_SALT', 'EjO?sQh6+%O4d?21((pU(dy<W~ pEH>)0tCP1_FmUwmE.]HTGHB`X6K{g%2<HL12' );
define( 'LOGGED_IN_SALT',   'bAcw}bCfIi)*Kz@N3Ac<Xa~iJsmGoFfmSD{Dlj.`,~!?ps+vcxA#Q#k/!44/G7p[' );
define( 'NONCE_SALT',       '~Fh3U_V!NR0],o3T(m<.*LTLRy[r%QMz.q5R+GGix*UPp]cyC _&7V$@iYw}Guq~' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
